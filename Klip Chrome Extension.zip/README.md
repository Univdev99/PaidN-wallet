# BoilerPlate React Klipp

Proyecto Boilerplate para la extension de Chrome de Klipp.


Accede al directiorio del proyecto y ejecuta:

### `npm install`
### `npm start`

Corre el aplicativo en.\
[http://localhost:3000](http://localhost:3000).
